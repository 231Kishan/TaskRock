import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import CharacterDetails from './CharacterDetails';

function App() {
  const [Data, setData] = useState([]);

  useEffect(() => {
    fetch('https://rickandmortyapi.com/api/character')
      .then((response) => response.json())
      .then((data) => setData(data.results))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <>
              <h1>Data</h1>
              <ul>
                {Data.map((ele) => (
                  <li key={ele.id}>
                    <Link to={`/character/${ele.id}`}>
                      <img src={ele.image} alt={ele.name} />
                      <h2>{ele.name}</h2>
                    </Link>
                    <p>Status: {ele.status}</p>
                  </li>
                ))}
              </ul>
            </>
          }
        />
        <Route path="/character/:id" element={<CharacterDetails data={Data} />} />
      </Routes>
    </Router>
  );
}

export default App;